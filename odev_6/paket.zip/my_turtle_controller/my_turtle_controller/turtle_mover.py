import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class TurtleMover(Node):
    def __init__(self):
        super().__init__('turtle_mover_node')
        # Publisher oluşturuyoruz: /turtle1/cmd_vel konusuna Twist mesajı yollayacak
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        
        # 0.5 saniyede bir veriyi göndermesi için zamanlayıcı
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.get_logger().info('Kaplumbağa hareket ettirici başlatıldı!')

    def timer_callback(self):
        msg = Twist()
        
        # Lineer (Düz) Hız (x ekseninde ileri)
        msg.linear.x = 2.0
        
        # Açısal (Dönme) Hız (z ekseninde dönme)
        msg.angular.z = 1.0
        
        # Mesajı yayınla
        self.publisher_.publish(msg)
        self.get_logger().info(f'Hız gönderiliyor: Linear X={msg.linear.x}, Angular Z={msg.angular.z}')

def main(args=None):
    rclpy.init(args=args)
    turtle_mover = TurtleMover()
    
    try:
        rclpy.spin(turtle_mover)
    except KeyboardInterrupt:
        pass
    finally:
        turtle_mover.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()